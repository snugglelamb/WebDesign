Zhi Li | 44005290

Link to Webpage:http://www.seas.upenn.edu/~zhili/lego.html
Link to Calendar:http://www.seas.upenn.edu/~zhili/calendar.html

special features of webpage:
	for test.html: (a demo page for LEGO movie intro)
	1. a sidebar menu is created, by clicking the menu button it will show up from the left side and push the body part to the right side. Then when you click on the cancel sign it will hide itself and everything comes back to normal. List and JQuery is used here to enable simple animation.
	2. The interface of webpage is carefully designed, try to use overflow control(scroll bar) for the first time, clickable image link, text link without decoration, font control via CSS etc.
	3. A button called "Friend me on Facebook" is created, on clicking it will lead to my personal facebook page.
	4. Table is used to organize embedded youtube videos, giving them a neat appearance.

Some thoughts:
	A week ago, I first learn a little bit JavaScript by myself, simply because it's interesting, but at that time I know nothing about html/CSS. On building my own webpage from scratch, I have to learn html/CSS as much as possible, and in the meantime I want to make my webpage more interactive by adding some JavaScripts in it. It took me quite a long time to digest CSS syntax and basic function of JQuery, mostly from the internet and codeacademy.Then I try to implement what I've learnt into this test.html webpage. I met quite a lot of problems in CSS contents when trying to enable JQuery function, in how to make the background cover the whole brower page, also in the outlay of interface etc. But it was quite fun indeed. Though it took me a lot of time, it's worth the efforts. :)
	